These two custom firmware are intended to use on a ZachTek Pico transmitter and will give more precise Altitude calculations when the option "Send precise location" is used in the Pico transmitter.
With this firmware loaded the Pico transmitter will only start WSPR transmission on specific minutes, this helps calculate a precise altitude on the http://lu7aa.org.ar/wsprcall.asp webpage
You need to first setup your details including your callsign on the Lua7aa website, you do that here: http://lu7aa.org.ar/wsprset.asp   * (See comment below for more info of what the different fields are used for) 
This firmware will designated "Zachtek1" in the "Tracker:" field  
(If you are using the standard firmware, you should instead use just "Zachtek" as Tracker)

Use the firmware "WSPR-TX1.00_TimeSlots00_Pico.hex" to start the WSPR transmission on minutes: 00, 10,20,30,40 and 50.
The firmware "WSPR-TX1.00_TimeSlots04_Pico.hex" will start transmissions on minutes: 04,14,24,34,44 and 54.
When the "Send precise location" is option is used, there will be two WSPR transmissions back-to-back so the transmission time on each band is 2 x 2 minutes= 4 minutes in total.
The first transmission will encode the Altitude with course precision and the second transmission will add more precision to the altitude. There is more information how this is calculated in the ZachTek PC configuration software https://github.com/HarrydeBug/1011-WSPR-TX_LP1/tree/master/PC%20Software/Release

The LU7AA.ORG site will pull received data from WSPRnet.org and will show a visual track for the balloon tracker, it can also push data to APRS.FI if you want.

73
//Harry - SM7PNV
PS I have a report that transmissions with "Send precise location" setting dows not show up properly if you callsing only has a single letter before the number e.g N1ABC, this might be bug in my firmware ,I have not verified it at this time (3rd of August 2021)
If your callsign has two letters before the number E.g WA1ABC, SM7PNV, LU1ESY etc.. it is verified to work fine. 


* Information from Pedro Converso � LU7ABF, creator of the webpage LU7AA.ORG website on what fields to use in the setup for a new ballon
Yes, Balloon ID is for qrplabs and wb8elk
Timeslot is also for same, but in case of zachtek1 2nd TLM ending
minute can be set.

+Details if set will show all TLMs, if not, will show one TLM with
Different datetimes
Yes tracker could be either zachtek (old coding) or zachtek1 (new coding)

When blue button is press, new setting will be automatically added and
could be used right away.
To delete any entry, clicking on 'Request change' will allow to send
me a mail to change/delete.
Feel free to enter new balloon data on presets, will guide if invalid
values entered.

If Ignacio launches two trackers with same callsign, they should have
different timeslot.
I.E. 2 for one balloon and 6 for the other balloon. (This is minute
end of 2nd TLM)
In all cases balloonid should be left blank or set to 00 for zachtek1
tracker selection.

If SSID is set between 00 and 99, then upload to aprs.fi will be
allowed with this SSID.
Upload to aprs.fi & habhub is only done when selected or auto repeat marked.

Hope to be helpful with explanations.

Best 73, and going forward !!

lu7abf, Pedro






